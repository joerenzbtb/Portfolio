print("Welcome to the Band Name Generator.")
city=input("What city did you grow up in?\n")
pet=input("What is the name of your pet?\n")
print("Your band name could be"+" "+city+" "+pet+".")